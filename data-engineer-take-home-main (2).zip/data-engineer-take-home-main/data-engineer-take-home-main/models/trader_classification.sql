-- Set the parameters
\set whale_percentage 1         -- The percentage threshold for whales (default > 1%)
\set nft_threshold 2            -- The NFT threshold for High-Value Holders (default ≥ 2 NFTs)
\set min_net_worth 5000         -- The minimum net worth threshold for High-Value Holders (default > $5k)

-- Main Query
WITH total_supply AS (
    -- Step 1: Calculate Total NFT Supply
    SELECT COUNT(DISTINCT decoded->>'tokenId') AS total_nfts
    FROM logs
    WHERE method = 'Transfer'
),
wallet_holdings AS (
    -- Step 2: Calculate Token Holdings for Each Wallet
    SELECT
        l.decoded->>'to' AS wallet,
        COUNT(DISTINCT l.decoded->>'tokenId') AS tokens_held
    FROM logs l
    WHERE l.method = 'Transfer'
    GROUP BY l.decoded->>'to'
)

-- Step 3: Whale Classification (wallets holding > 1% of supply)
SELECT
    'Whale' AS classification,
    wallet,
    tokens_held,
    (tokens_held::FLOAT / total_nfts) * 100 AS percentage_of_supply
FROM wallet_holdings, total_supply
WHERE (tokens_held::FLOAT / total_nfts) * 100 > :whale_percentage

UNION ALL

-- Step 4: High-Value Holder Classification (wallets with ≥ 2 NFTs and net worth > $5k)
SELECT
    'High-Value Holder' AS classification,
    wallet,
    tokens_held,
    NULL AS percentage_of_supply  -- Adding a placeholder for the missing column
FROM wallet_holdings
WHERE tokens_held >= :nft_threshold
AND tokens_held * 1000 > :min_net_worth;  -- Placeholder for actual net worth comparison (assuming $1000 per NFT for simplicity)
