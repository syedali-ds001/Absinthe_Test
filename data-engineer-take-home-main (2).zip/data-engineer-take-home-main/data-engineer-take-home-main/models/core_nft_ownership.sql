-- WITH nft_transfers AS (
--     -- Get NFT transfer transactions from logs and transactions
--     SELECT
--         t."from" AS address,
--         t.transaction_hash,
--         t.block_timestamp AS transfer_timestamp,
--         l.decoded->>'tokenId' AS token_id -- Correctly extract tokenId from decoded JSON
--     FROM
--         transactions t
--     JOIN
--         logs l ON t.transaction_hash = l.transaction_hash
--     WHERE
--         l.method = 'transfer'  -- Filter logs for transfer-related method

--     UNION ALL

--     -- Get NFT transfers directly from logs if no corresponding transactions
--     SELECT
--         l.address AS address,
--         l.transaction_hash,
--         t.block_timestamp AS transfer_timestamp, -- Use block_timestamp from transactions
--         l.decoded->>'tokenId' AS token_id -- Correctly extract tokenId from decoded JSON
--     FROM
--         logs l
--     JOIN
--         transactions t ON l.transaction_hash = t.transaction_hash
--     WHERE
--         l.method = 'Transfer'  -- Filter logs for transfer-related method
-- ),
-- aggregated_transfers AS (
--     -- Aggregate NFT transfers to get total tokens and timestamps per wallet
--     SELECT
--         address,
--         COUNT(DISTINCT token_id) AS total_tokens_held,
--         MIN(transfer_timestamp) AS first_transfer_timestamp,
--         MAX(transfer_timestamp) AS last_transfer_timestamp
--     FROM
--         nft_transfers
--     GROUP BY
--         address
-- )
-- -- Now, join with wallet_networth to get the net worth and balance information for each wallet
-- SELECT
--     at.address,
--     at.total_tokens_held,
--     at.first_transfer_timestamp,
--     at.last_transfer_timestamp,
--     wn.total_networth_usd,
--     wn.native_balance,
--     wn.native_balance_usd,
--     wn.token_balance_usd
-- FROM
--     aggregated_transfers at
-- JOIN
--     wallet_networth wn ON at.address = wn.address;



-- WITH nft_transfers AS (
--     SELECT
--         l.transaction_hash,
--         l.chain_id,
--         l.address AS nft_address,
--         t.block_timestamp AS transfer_timestamp,
--         l.decoded->>'from' AS from_wallet,
--         l.decoded->>'to' AS to_wallet,
--         l.decoded->>'tokenId' AS token_id
--     FROM logs l
--     JOIN transactions t
--         ON l.transaction_hash = t.transaction_hash
--         AND l.chain_id = t.chain_id
--     WHERE l.method = 'Transfer'
-- )
-- SELECT
--     nft_address AS address,
--     COUNT(DISTINCT token_id) AS total_tokens_held,
--     MIN(transfer_timestamp) AS first_transfer_timestamp,
--     MAX(transfer_timestamp) AS last_transfer_timestamp,
--     wn.total_networth_usd,
--     wn.native_balance,
--     wn.native_balance_usd,
--     wn.token_balance_usd
-- FROM nft_transfers nft
-- JOIN wallet_networth wn
--     ON wn.address IN (nft.from_wallet, nft.to_wallet)
-- GROUP BY nft_address, wn.total_networth_usd, wn.native_balance, wn.native_balance_usd, wn.token_balance_usd;



WITH nft_transfers AS (
    SELECT
        l.transaction_hash,
        l.chain_id,
        l.address AS nft_address,
        t.block_timestamp AS transfer_timestamp,
        l.decoded->>'from' AS from_wallet,
        l.decoded->>'to' AS to_wallet,
        l.decoded->>'tokenId' AS token_id
    FROM logs l
    JOIN transactions t
        ON l.transaction_hash = t.transaction_hash
        AND l.chain_id = t.chain_id
    WHERE l.method = 'Transfer'
)
SELECT
    nft_address AS address,
    COUNT(DISTINCT token_id) AS total_tokens_held,
    MIN(transfer_timestamp) AS first_transfer_timestamp,
    MAX(transfer_timestamp) AS last_transfer_timestamp
FROM nft_transfers nft
GROUP BY nft_address;
