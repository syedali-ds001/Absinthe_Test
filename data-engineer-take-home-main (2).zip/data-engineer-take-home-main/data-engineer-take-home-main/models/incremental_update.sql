-- CREATE TABLE nft_last_processed (
--     chain_id INTEGER,
--     last_processed_timestamp TIMESTAMP WITH TIME ZONE,
--     PRIMARY KEY (chain_id)
-- );


WITH nft_transfers AS (
    SELECT
        l.transaction_hash,
        l.chain_id,
        l.address AS nft_address,
        t.block_timestamp AS transfer_timestamp,
        l.decoded->>'from' AS from_wallet,
        l.decoded->>'to' AS to_wallet,
        l.decoded->>'tokenId' AS token_id
    FROM logs l
    JOIN transactions t
        ON l.transaction_hash = t.transaction_hash
        AND l.chain_id = t.chain_id
    WHERE l.method = 'Transfer'
    AND t.block_timestamp > (SELECT last_processed_timestamp FROM nft_last_processed WHERE chain_id = l.chain_id)
)
SELECT
    nft_address AS address,
    COUNT(DISTINCT token_id) AS total_tokens_held,
    MIN(transfer_timestamp) AS first_transfer_timestamp,
    MAX(transfer_timestamp) AS last_transfer_timestamp
FROM nft_transfers nft
GROUP BY nft_address;

-- Update the last processed timestamp
INSERT INTO nft_last_processed (chain_id, last_processed_timestamp)
VALUES 
    (1, NOW())  -- Replace with actual chain_id and timestamp
ON CONFLICT (chain_id)
DO UPDATE SET last_processed_timestamp = NOW();
