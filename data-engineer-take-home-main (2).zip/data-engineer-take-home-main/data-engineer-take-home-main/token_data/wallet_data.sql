-- Create the wallet_networth table
CREATE TABLE wallet_networth (
    address VARCHAR(255) PRIMARY KEY,
    total_networth_usd NUMERIC,
    native_balance NUMERIC,
    native_balance_usd NUMERIC,
    token_balance_usd NUMERIC
);

-- Import data from CSV file
\COPY wallet_networth (address, total_networth_usd, native_balance, native_balance_usd, token_balance_usd)
FROM 'C:\\Users\\Syed Khizar Rayaz\\Downloads\\data-engineer-take-home-main\\data-engineer-take-home-main\\token_data\\wallet_networth.csv'
DELIMITER ','
CSV HEADER;